<?php

/**
 * Fired during plugin activation
 *
 * @link       https://app.vpnresellers.com/
 * @since      1.0.0
 *
 * @package    vpn_resellers
 * @subpackage vpn_resellers/includes
 */

class vpn_resellers_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
