<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://app.vpnresellers.com/
 * @since      1.0.0
 *
 * @package    Vpn_Resellers
 * @subpackage vpn_resellers/includes
 */


class vpn_resellers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
