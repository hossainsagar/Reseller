<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * @link       https://app.vpnresellers.com/
 * @since      1.0.0
 *
 * @package    Vpn_Resellers
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
