<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://app.vpnresellers.com/
 * @since      1.0.0
 *
 * @package    vpn_resellers
 * @subpackage vpn_resellers/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    vpn_resellers
 * @subpackage vpn_resellers/admin
 * @author     Author
 */
class vpn_resellers_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		add_action('admin_menu', array($this, 'addPluginAdminMenu'), 9);
		add_action('admin_init', array($this, 'registerAndBuildFields'));
		add_action('woocommerce_product_options_general_product_data', array($this, 'addCheckboxinWoo'), 10);
		add_action('woocommerce_process_product_meta', array($this, 'saveCheckboxinWoo'));
		add_action('woocommerce_thankyou', array($this, 'createVpnResellerAccount'));

		// add my-account page for VPN account
		add_action('init', array($this, 'add_vpn_account_endpoint'));
		add_filter('query_vars', array($this, 'vpn_account_query_vars'), 0);
		add_filter('woocommerce_account_menu_items', array($this, 'vpn_account_password_link_my_account'));
		add_action('woocommerce_account_vpn-account_endpoint', array($this, 'vpn_account_content'));

		//add my-account page to list servers
		add_action('init', array($this, 'add_vpn_servers_endpoint'));
		add_filter('query_vars', array($this, 'vpn_servers_query_vars'), 0);
		add_filter('woocommerce_account_menu_items', array($this, 'add_vpn_servers_link_my_account'));
		add_action('woocommerce_account_vpn-server-list_endpoint', array($this, 'vpn_server_list_content'));

		// add my-account page for change password
		add_action('init', array($this, 'add_change_vpn_password_endpoint'));
		add_filter('query_vars', array($this, 'change_vpn_password_query_vars'), 0);
		add_filter('woocommerce_account_menu_items', array($this, 'add_change_vpn_password_link_my_account'));
		add_action('woocommerce_account_change-vpn-password_endpoint', array($this, 'change_vpn_password_content'));

		// deactivate VPN account when subscription of woo expires

		add_action('woocommerce_subscription_status_expired', array($this, 'deactivate_vpn_account'), 10);
		add_action('woocommerce_subscription_status_updated', array($this, 'suspend_vpn_account'), 10, 3);

	}

	public function suspend_vpn_account($subscription, $new_status, $old_status)
	{

		$user = new WP_User($subscription->get_user_id());
		$username = $user->user_email;
		$user_id = $subscription->get_user_id();
		$vpn_account_id = get_user_meta($user_id, 'vpn_account_id', true);
		if (!empty($vpn_account_id)) {
			if (sizeof($subscription_items = $subscription->get_items()) > 0) {
				foreach ($subscription_items as $item_id => $item) {
					$product = $item->get_product();
					$product_id = $product->get_id();
					$is_vpn = get_post_meta($product_id, 'is_vpn', true);

					if ($is_vpn == 'yes') {
						if ($new_status == 'on-hold' || $new_status == 'cancelled') {
							update_user_meta($user_id, 'vpn_account_status', 'disable');
							$client = new \GuzzleHttp\Client();
							$acces_token = get_option('vpn_resellers_setting');
							try {
								$response = $client->put("https://api.vpnresellers.com/v3_1/accounts/" . $vpn_account_id . "/disable", [
									'headers' => [
										"Authorization" => "Bearer " . $acces_token,
										"Accept" => "application/json",
									],
								]);
								$response_code = $response->getStatusCode();
							} catch (GuzzleHttp\Exception\ClientException $e) {
								$response = $e->getResponse();
								$response_code = $response->getStatusCode();
							}
						}

						if ($new_status == 'active') {
							update_user_meta($user_id, 'vpn_account_status', 'active');
							$client = new \GuzzleHttp\Client();
							$acces_token = get_option('vpn_resellers_setting');
							try {
								$response = $client->put("https://api.vpnresellers.com/v3_1/accounts/" . $vpn_account_id . "/enable", [
									'headers' => [
										"Authorization" => "Bearer " . $acces_token,
										"Accept" => "application/json",
									],
								]);
								$response_code = $response->getStatusCode();
							} catch (GuzzleHttp\Exception\ClientException $e) {
								$response = $e->getResponse();
								$response_code = $response->getStatusCode();
							}
						}

					}
				}
			}
		}

	}
	public function deactivate_vpn_account($subscription)
	{
		$user = new WP_User($subscription->get_user_id());
		$username = $user->user_email;
		$user_id = $subscription->get_user_id();
		$vpn_account_id = get_user_meta($user_id, 'vpn_account_id', true);
		if (!empty($vpn_account_id)) {
			$client = new \GuzzleHttp\Client();
			$acces_token = get_option('vpn_resellers_setting');
			try {
				$response = $client->put("https://api.vpnresellers.com/v3_1/accounts/" . $vpn_account_id . "/disable", [
					'headers' => [
						"Authorization" => "Bearer " . $acces_token,
						"Accept" => "application/json",
					],
				]);
				$response_code = $response->getStatusCode();
			} catch (GuzzleHttp\Exception\ClientException $e) {
				$response = $e->getResponse();
				$response_code = $response->getStatusCode();
			}
		}
	}

	public function vpn_has_active_subscription($user_id = '')
	{
		if (function_exists('wcs_user_has_subscription')) {
			// When a $user_id is not specified, get the current user Id
			if ('' == $user_id && is_user_logged_in())
				$user_id = get_current_user_id();
			// User not logged in we return false
			if ($user_id == 0)
				return false;

			return wcs_user_has_subscription($user_id, '', 'active');
		} else {
			return false;
		}
	}
	public function change_vpn_password_content()
	{
		$current_user = wp_get_current_user();
		$vpn_account_id = get_user_meta($current_user->ID, 'vpn_account_id', true);

		if (!empty($vpn_account_id)) {

			if (isset($_POST['vpn_account_id']) && !empty($_POST['vpn_account_id'])) {

				if ($_POST['new_pass'] == $_POST['retype_pass']) {
					$response_code = '';
					$client = new \GuzzleHttp\Client();
					$acces_token = get_option('vpn_resellers_setting');

					try {
						$response = $client->put("https://api.vpnresellers.com/v3_1/accounts/" . $vpn_account_id . "/change_password", [
							'headers' => [
								"Authorization" => "Bearer " . $acces_token,
								"Accept" => "application/json",
								"Content-Type" => "application/json",
							],
							'json' => [
								"password" => $_POST['retype_pass'],
							],
						]);
						$response_code = $response->getStatusCode();
					} catch (GuzzleHttp\Exception\ClientException $e) {
						$response = $e->getResponse();
						$response_code = $response->getStatusCode();
					}

					if ($response_code == 200) {

						echo '<p class="vpn-success"> Password changed successfully.</p>';
						update_user_meta($current_user->ID, 'vpn_account_password', $_POST['retype_pass']);

					} elseif ($response_code == 422) {

						echo '<p class="vpn-error"> The password must be at least 6 characters.</p>';
					} else {

						echo '<p class="vpn-error"> Oops! Something went wrong. Please try again.</p>';
					}

				} else {
					echo '<p> Password mis-match, please type again.</p>';
				}
			}

			echo '<form method="post">
			<input type="hidden" name="vpn_account_id" value="' . $vpn_account_id . '">
			<h3>Change VPN Password</h3>
			<div class="woocommerce-address-fields">
		
				<div class="woocommerce-address-fields__field-wrapper">
					<p class="form-row form-row-first validate-required" id="new_pass" data-priority="10"><label
							for="new_pass" class="">New Password&nbsp;<abbr class="required"
								title="required">*</abbr></label><span class="woocommerce-input-wrapper"><input type="password"
								class="input-text " name="new_pass" id="new_pass" placeholder=" Type your new password"
								value="" >
							<div data-lastpass-icon-root="true"
								style="position: relative !important; height: 0px !important; width: 0px !important; float: left !important;">
							</div>
						</span></p>
					<p class="form-row form-row-last validate-required" id="retype_pass" data-priority="20"><label
							for="retype_pass" class="">Re-Type new password &nbsp;<abbr class="required"
								title="required">*</abbr></label><span class="woocommerce-input-wrapper"><input type="password"
								class="input-text " name="retype_pass" id="retype_pass" placeholder="Re-Type your new password" value=""
								></span></p>
					
				   
				</div>
		
		
				<p>
					<button type="submit" class="button wp-element-button" name="change_password" value="change password">Submit</button>
					
				</p>
			</div>
		
		</form>';

		}
	}
	public function add_change_vpn_password_link_my_account($items)
	{
		$items['change-vpn-password'] = 'Change VPN Password';
		return $items;
	}
	public function change_vpn_password_query_vars($vars)
	{
		$vars[] = 'change-vpn-password';
		return $vars;
	}
	public function add_change_vpn_password_endpoint()
	{
		add_rewrite_endpoint('change-vpn-password', EP_ROOT | EP_PAGES);
	}

	public function vpn_account_content()
	{
		$current_user = wp_get_current_user();
		$vpn_account_id = get_user_meta($current_user->ID, 'vpn_account_id', true);
		$vpn_account_password = get_user_meta($current_user->ID, 'vpn_account_password', true);

		if (!empty($vpn_account_id)) {



			echo '<p><label>Your VPN account username is </label><b>' . $current_user->user_email . '</b>';
			echo '<p><label>Your VPN account password is </label><b>' . $vpn_account_password . '</b>';

		}
	}
	public function vpn_account_password_link_my_account($items)
	{
		$items['vpn-account'] = 'VPN Account';
		return $items;
	}
	public function vpn_account_query_vars($vars)
	{
		$vars[] = 'vpn-account';
		return $vars;
	}
	public function add_vpn_account_endpoint()
	{
		add_rewrite_endpoint('vpn-account', EP_ROOT | EP_PAGES);
	}

	function vpn_server_list_content()
	{
		$current_user = wp_get_current_user();
		$client = new \GuzzleHttp\Client();
		$acces_token = get_option('vpn_resellers_setting');
		$vpn_account_status = get_user_meta($current_user->ID, 'vpn_account_status', true);
		$response_code = 200;
		if ($this->vpn_has_active_subscription() && $vpn_account_status == 'active') {
			try {
				$client->get("https://api.vpnresellers.com/v3_1/accounts/check_username", [
					'headers' => [
						"Authorization" => "Bearer " . $acces_token,
						"Accept" => "application/json",
					],
					'query' => [
						"username" => $current_user->user_email,
					],
				]);
			} catch (GuzzleHttp\Exception\ClientException $e) {
				$response = $e->getResponse();
				$response_code = $response->getStatusCode();
			}
			//print_r(json_decode((string) $body));
			echo '<h3>Server List</h3>';
			if ($response_code == 200) {
				echo '<p>You have not purchased VPN servers yet.</p>';
			} else {

				$response = $client->get("https://api.vpnresellers.com/v3_1/servers", [
					'headers' => [
						"Authorization" => "Bearer " . $acces_token,
						"Accept" => "application/json",
					],
				]);
				$body = $response->getBody();
				global $woocommerce;
				$server_list = json_decode((string) $body);

				$response = $client->get("https://api.vpnresellers.com/v3_1/ports", [
					'headers' => [
						"Authorization" => "Bearer " . $acces_token,
						"Accept" => "application/json",
					],
				]);
				$body = $response->getBody();
				$ports = json_decode((string) $body);
				//print_r($server_list);
				echo '<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
			<thead>
				<tr><th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr">Server Address</span></th><th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-date"><span class="nobr">Location</span></th><th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr">Download Openvpn Config file</span></th></tr>
			</thead>
	
			<tbody>';
				foreach ($server_list->data as $server) {

					echo '<tr class="woocommerce-orders-table__row">
												<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Order">
																<img src="' . $server->icon . '" />
										' . $server->name . '							
	
														</td>
												<td class="woocommerce-orders-table__cell" data-title="Date">
																<time>' . $server->city . ', ' . WC()->countries->countries[$server->country_code] . '</time>
	
														</td>
												<td class="woocommerce-orders-table__cell">';
					echo '<select class="port-list" data-server-id="' . $server->id . '">';
					foreach ($ports->data as $port) {
						echo '<option value="' . $port->id . '">' . $port->protocol . ' ' . $port->number;
					}
					echo '</select>';
					echo ' <a id="download-button-' . $server->id . '" class="btn btn-sm" href="#" target="_blank">Download</a>
														</td>
												
										</tr>';
				}
				echo '</tbody>
		</table>';
				?>
				<script>		jQuery(document).ready(function () {			jQuery('.port-list').each(function () {				setDownloadLink(jQuery(this));			});
						});		jQuery('.port-list').on("change", function () {			setDownloadLink(jQuery(this));		});		function setDownloadLink(selectElement) {			let serverId = selectElement.data('server-id');			let portId = selectElement.children("option:selected").val();			let url = 'https://api.321inter.net/v4/configuration/download?port_id=' + portId + '&server_id=' + serverId;			jQuery('#download-button-' + serverId).attr('href', url);		}
				</script>
				<?php
			}

		} else {
			echo '<p>You have not purchased VPN servers yet.</p>';
		}

	}
	public function add_vpn_servers_link_my_account($items)
	{
		$items['vpn-server-list'] = 'VPN Server List';
		return $items;
	}
	public function vpn_servers_query_vars($vars)
	{
		$vars[] = 'vpn-server-list';
		return $vars;
	}
	public function add_vpn_servers_endpoint()
	{
		add_rewrite_endpoint('vpn-server-list', EP_ROOT | EP_PAGES);
	}

	public function createVpnResellerAccount($order_id)
	{


		//create an order instance
		$order = wc_get_order($order_id);
		$orderstat = $order->get_status();
		if ($orderstat == 'processing' || $orderstat == 'completed') {
			$current_user = wp_get_current_user();
			$items = $order->get_items();
			foreach ($items as $item) {
				$product_id = $item->get_product_id();
				$is_vpn = get_post_meta($product_id, 'is_vpn', true);

				if ($is_vpn == 'yes') {
					// Get the Customer billing email
					if (empty($current_user)) {
						$username = $order->get_billing_email();
					} else {
						$username = $current_user->user_email;
					}
					$client = new \GuzzleHttp\Client();
					$acces_token = get_option('vpn_resellers_setting');
					$response_code = 200;

					try {
						$client->get("https://api.vpnresellers.com/v3_1/accounts/check_username", [
							'headers' => [
								"Authorization" => "Bearer " . $acces_token,
								"Accept" => "application/json",
							],
							'query' => [
								"username" => $username,
							],
						]);
					} catch (GuzzleHttp\Exception\ClientException $e) {
						$response = $e->getResponse();
						$response_code = $response->getStatusCode();
					}

					if ($response_code == 200) {
						$vpn_account_password = wp_generate_password();
						try {
							$response = $client->post("https://api.vpnresellers.com/v3_1/accounts", [
								'headers' => [
									"Authorization" => "Bearer " . $acces_token,
									"Accept" => "application/json",
									"Content-Type" => "application/json",
								],
								'json' => [
									"username" => $username,
									"password" => $vpn_account_password,
								],
							]);

							$response_code = $response->getStatusCode();
						} catch (GuzzleHttp\Exception\ClientException $e) {
							$response = $e->getResponse();
							$response_code = $response->getStatusCode();
						}
					}

					if ($response_code == 201) {

						$body = $response->getBody();
						$vpn_user_data = json_decode((string) $body);
						if ($current_user->ID) {
							update_user_meta($current_user->ID, 'vpn_account_id', $vpn_user_data->data->id);
							update_user_meta($current_user->ID, 'vpn_account_password', $vpn_account_password);
							update_user_meta($current_user->ID, 'vpn_wg_private_key', $vpn_user_data->data->wg_private_key);
							update_user_meta($current_user->ID, 'vpn_wg_public_key', $vpn_user_data->data->wg_public_key);
							update_user_meta($current_user->ID, 'vpn_wg_ip', $vpn_user_data->data->wg_ip);
							update_user_meta($current_user->ID, 'vpn_account_status', 'active');

							$to = $current_user->user_email;
							$subject = 'Your VPN account details';
							$body = '<p>Thank you for purchasing VPN</p>

							<p>Your VPN username: ' . $current_user->user_email . '</p>
							<p>Your VPN password: ' . $vpn_account_password . '</p>
							
							</p>To change your password, login to our website and click on the "Change VPN password" tab.</p>';
							$headers = array('Content-Type: text/html; charset=UTF-8');

							wp_mail($to, $subject, $body, $headers);
						}
					}
					$vpn_account_password = get_user_meta($current_user->ID, 'vpn_account_password', true);
					echo '<p><label>Your VPN account username is </label><b>' . $current_user->user_email . '</b>';
					echo '<p><label>Your VPN account password is </label><b>' . $vpn_account_password . '</b>';
				}
			}
		}


	}
	public function addCheckboxinWoo()
	{

		global $post;

		$input_checkbox = get_post_meta($post->ID, 'is_vpn', true);
		if (empty($input_checkbox))
			$input_checkbox = '';

		woocommerce_wp_checkbox(
			array(
				'id' => 'is_vpn',
				'label' => __('VPN product?', 'woocommerce'),
				'description' => __('Yes', 'woocommerce'),
				'value' => $input_checkbox,
			)
		);
	}
	public function saveCheckboxinWoo()
	{
		global $post;

		$_custom_text_option = isset($_POST['is_vpn']) ? 'yes' : '';
		update_post_meta($post->ID, 'is_vpn', $_custom_text_option);
	}
	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in vpn_resellers_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The vpn_resellers_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/vpn-resellers-admin.css', array(), $this->version, 'all');

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in vpn_resellers_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The vpn_resellers_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/vpn-resellers-admin.js', array('jquery'), $this->version, false);

	}
	public function addPluginAdminMenu()
	{
		//add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
		add_menu_page($this->plugin_name, 'VPNresellers', 'administrator', $this->plugin_name, array($this, 'displayPluginAdminSettings'), 'dashicons-networking', 26);

		//add_submenu_page( '$parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function );
		//add_submenu_page( $this->plugin_name, 'VPN Resellers Settings', 'Settings', 'administrator', $this->plugin_name.'-settings', array( $this, 'displayPluginAdminSettings' ));
	}
	public function displayPluginAdminDashboard()
	{
		require_once 'partials/' . $this->plugin_name . '-admin-display.php';
	}
	public function displayPluginAdminSettings()
	{
		// set this var to be used in the settings-display view
		$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
		if (isset($_GET['error_message'])) {
			add_action('admin_notices', array($this, 'vpnResllersSettingsMessages'));
			do_action('admin_notices', $_GET['error_message']);
		}
		require_once 'partials/' . $this->plugin_name . '-admin-settings-display.php';
	}
	public function vpnResllersSettingsMessages($error_message)
	{
		switch ($error_message) {
			case '1':
				$message = __('There was an error adding this setting. Please try again.  If this persists, shoot us an email.', 'my-text-domain');
				$err_code = esc_attr('vpn_resellers_setting');
				$setting_field = 'vpn_resellers_setting';
				break;
		}
		$type = 'error';
		add_settings_error(
			$setting_field,
			$err_code,
			$message,
			$type
		);
	}
	public function registerAndBuildFields()
	{
		/**
		 * First, we add_settings_section. This is necessary since all future settings must belong to one.
		 * Second, add_settings_field
		 * Third, register_setting
		 */
		add_settings_section(
			// ID used to identify this section and with which to register options
			'vpn_resellers_general_section',
			// Title to be displayed on the administration page
			'',
			// Callback used to render the description of the section
			array($this, 'vpn_resellers_display_general_account'),
			// Page on which to add this section of options
			'vpn_resellers_general_settings'
		);
		unset($args);
		$args = array(
			'type' => 'input',
			'subtype' => 'text',
			'id' => 'vpn_resellers_setting',
			'name' => 'vpn_resellers_setting',
			'required' => 'true',
			'get_options_list' => '',
			'value_type' => 'normal',
			'wp_data' => 'option'
		);
		add_settings_field(
			'vpn_resellers_setting',
			'API Token',
			array($this, 'vpn_resellers_render_settings_field'),
			'vpn_resellers_general_settings',
			'vpn_resellers_general_section',
			$args
		);


		register_setting(
			'vpn_resellers_general_settings',
			'vpn_resellers_setting'
		);

	}
	public function vpn_resellers_display_general_account()
	{
		echo '<p>Please add your VPN Resellers API access Token here</p>';
		echo '<p><a href="https://www.vpnresellers.com/blog/wordpress-whitelabel-vpn-integration
		" target="_blank"> Installation tutorial</a></p>';
	}
	public function vpn_resellers_render_settings_field($args)
	{
		/* EXAMPLE INPUT
		'type'      => 'input',
		'subtype'   => '',
		'id'    => $this->plugin_name.'_setting',
		'name'      => $this->plugin_name.'_setting',
		'required' => 'required="required"',
		'get_option_list' => "",
		'value_type' = serialized OR normal,
		'wp_data'=>(option or post_meta),
		'post_id' =>
		*/
		if ($args['wp_data'] == 'option') {
			$wp_data_value = get_option($args['name']);
		} elseif ($args['wp_data'] == 'post_meta') {
			$wp_data_value = get_post_meta($args['post_id'], $args['name'], true);
		}

		switch ($args['type']) {

			case 'input':
				$value = ($args['value_type'] == 'serialized') ? serialize($wp_data_value) : $wp_data_value;
				if ($args['subtype'] != 'checkbox') {
					$prependStart = (isset($args['prepend_value'])) ? '<div class="input-prepend"> <span class="add-on">' . $args['prepend_value'] . '</span>' : '';
					$prependEnd = (isset($args['prepend_value'])) ? '</div>' : '';
					$step = (isset($args['step'])) ? 'step="' . $args['step'] . '"' : '';
					$min = (isset($args['min'])) ? 'min="' . $args['min'] . '"' : '';
					$max = (isset($args['max'])) ? 'max="' . $args['max'] . '"' : '';
					if (isset($args['disabled'])) {
						// hide the actual input bc if it was just a disabled input the info saved in the database would be wrong - bc it would pass empty values and wipe the actual information
						echo $prependStart . '<input type="' . $args['subtype'] . '" id="' . $args['id'] . '_disabled" ' . $step . ' ' . $max . ' ' . $min . ' name="' . $args['name'] . '_disabled" size="40" disabled value="' . esc_attr($value) . '" /><input type="hidden" id="' . $args['id'] . '" ' . $step . ' ' . $max . ' ' . $min . ' name="' . $args['name'] . '" size="40" value="' . esc_attr($value) . '" />' . $prependEnd;
					} else {
						echo $prependStart . '<input type="' . $args['subtype'] . '" id="' . $args['id'] . '" "' . $args['required'] . '" ' . $step . ' ' . $max . ' ' . $min . ' name="' . $args['name'] . '" size="40" value="' . esc_attr($value) . '" />' . $prependEnd;
					}
					/*<input required="required" '.$disabled.' type="number" step="any" id="'.$this->plugin_name.'_cost2" name="'.$this->plugin_name.'_cost2" value="' . esc_attr( $cost ) . '" size="25" /><input type="hidden" id="'.$this->plugin_name.'_cost" step="any" name="'.$this->plugin_name.'_cost" value="' . esc_attr( $cost ) . '" />*/

				} else {
					$checked = ($value) ? 'checked' : '';
					echo '<input type="' . $args['subtype'] . '" id="' . $args['id'] . '" "' . $args['required'] . '" name="' . $args['name'] . '" size="40" value="1" ' . $checked . ' />';
				}
				break;
			default:
				# code...
				break;
		}
	}
}